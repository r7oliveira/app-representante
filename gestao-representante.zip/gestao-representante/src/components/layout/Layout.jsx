// src/components/layout/Layout.jsx
import { Outlet, useNavigate, useLocation } from 'react-router-dom'
import styles from './Layout.module.css'

const NAV_ITEMS = [
  { path: '/semana',      icon: '🏠', label: 'Semana' },
  { path: '/consultoras', icon: '👥', label: 'Consultoras' },
  { path: '/mais',        icon: '⋯',  label: 'Mais' },
]

export default function Layout() {
  const navigate  = useNavigate()
  const location  = useLocation()

  // Esconde a nav durante o atendimento (foco total)
  const hideNav = location.pathname.startsWith('/atendimento')

  return (
    <div className={styles.shell}>
      <main className={styles.main}>
        <Outlet />
      </main>

      {!hideNav && (
        <nav className={styles.nav}>
          {NAV_ITEMS.map(item => {
            const active = location.pathname.startsWith(item.path)
            return (
              <button
                key={item.path}
                className={`${styles.navItem} ${active ? styles.active : ''}`}
                onClick={() => navigate(item.path)}
              >
                <span className={styles.navIcon}>{item.icon}</span>
                <span className={styles.navLabel}>{item.label}</span>
              </button>
            )
          })}
        </nav>
      )}
    </div>
  )
}
