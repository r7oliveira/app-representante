export default function ScreenMais() {
  return <div style={{ padding: 24, fontFamily: 'Inter', fontWeight: 700, color: '#6B6478' }}>🔧 ScreenMais — em breve</div>
}
