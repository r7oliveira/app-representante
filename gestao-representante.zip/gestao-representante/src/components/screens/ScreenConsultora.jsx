export default function ScreenConsultora() {
  return <div style={{ padding: 24, fontFamily: 'Inter', fontWeight: 700, color: '#6B6478' }}>🔧 ScreenConsultora — em breve</div>
}
