// src/components/screens/ScreenConsultoras.jsx
export default function ScreenConsultoras() {
  return <div style={{ padding: 24, fontFamily: 'Inter', fontWeight: 700, color: '#6B6478' }}>📋 Consultoras — em breve</div>
}
