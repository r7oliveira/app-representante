// src/components/screens/ScreenAtendimento.jsx
import { useState, useEffect } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import styles from './ScreenAtendimento.module.css'

const MOCK = {
  id: '3', nome: 'Juliana Rocha', iniciais: 'JR',
  cidade: 'Gramado', telefone: '(54) 99917-4832',
  status: 'Ativa', score: 60,
  ultimaVenda: 820, ultimoPagamento: 820,
  debito: 400, ticketMedio: 690,
  pedidoFavoritaUltimo: false,
  posicao: 13, total: 30,
  mediaTempo: 24, // minutos
}

export default function ScreenAtendimento() {
  const navigate   = useNavigate()
  const { id }     = useParams()
  const [inicio]   = useState(new Date())
  const [minutos, setMinutos] = useState(0)
  const [favoritaSim, setFavoritaSim] = useState(null)
  const c = MOCK

  // Cronômetro
  useEffect(() => {
    const timer = setInterval(() => {
      setMinutos(Math.floor((Date.now() - inicio.getTime()) / 60000))
    }, 10000) // atualiza a cada 10s
    return () => clearInterval(timer)
  }, [inicio])

  const horaInicio = inicio.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })

  const handleFinalizar = () => {
    // TODO: salvar no Firebase
    navigate('/semana')
  }

  return (
    <div className={styles.screen}>

      {/* ── Header verde escuro ── */}
      <div className={styles.header}>
        <button className={styles.back} onClick={() => navigate(-1)}>
          ← Semana 32 · Gramado 3
        </button>

        <div className={styles.topRow}>
          <div className={styles.av}>{c.iniciais}</div>
          <div>
            <div className={styles.nome}>{c.nome}</div>
            <div className={styles.cidade}>{c.cidade} · {c.telefone}</div>
            <div className={styles.statusPill}>● {c.status}</div>
          </div>
          <div className={styles.posBadge}>{c.posicao}/{c.total}</div>
        </div>

        {/* Cronômetro */}
        <div className={styles.timer}>
          <div className={styles.timerBlock}>
            <div className={styles.timerLabel}>Iniciado às</div>
            <div className={styles.timerVal}>{horaInicio}</div>
          </div>
          <div className={styles.timerDivider} />
          <div className={styles.timerBlock}>
            <div className={styles.timerLabel}>Tempo</div>
            <div className={`${styles.timerVal} ${styles.timerGreen}`}>
              {minutos} min
            </div>
          </div>
          <div className={styles.timerDivider} />
          <div className={styles.timerBlock} style={{ textAlign: 'right' }}>
            <div className={styles.timerLabel}>Média dela</div>
            <div className={styles.timerValMuted}>{c.mediaTempo} min</div>
          </div>
        </div>
      </div>

      {/* ── Conteúdo scrollável ── */}
      <div className={`${styles.body} scroll`}>

        {/* Score + resumo */}
        <div className={styles.card}>
          <div className={styles.cardHeader}>
            <span className={styles.cardTitle}>Histórico</span>
            <span className={styles.scorePill}>Score {c.score}</span>
          </div>
          <div className={styles.statsGrid}>
            <StatItem label="Última venda"   value={fmt(c.ultimaVenda)}     />
            <StatItem label="Último pgto"    value={fmt(c.ultimoPagamento)}  color="green" />
            <StatItem label="Débito atual"   value={fmt(c.debito)}           color="red"   />
            <StatItem label="Ticket médio"   value={fmt(c.ticketMedio)}      />
          </div>
        </div>

        {/* Pedido Favorita status */}
        <div className={styles.favStatus}>
          <span className={styles.favIcon}>📦</span>
          <div>
            <div className={styles.favTitle}>Pedido favorita no último atendimento</div>
            <div className={styles.favSub} style={{ color: c.pedidoFavoritaUltimo ? 'var(--green)' : 'var(--amber)' }}>
              {c.pedidoFavoritaUltimo ? 'Realizado ✓' : 'Não realizado'}
            </div>
          </div>
        </div>

        {/* ── Botões grandes ── */}
        <div className={styles.actions}>

          {/* Pedido Favorita */}
          <div className={styles.favoritaBtn}>
            <span className={styles.favoritaBtnIcon}>📦</span>
            <div className={styles.favoritaBtnText}>
              <div className={styles.favoritaBtnTitle}>Pedido Favorita</div>
              <div className={styles.favoritaBtnSub}>Marcar realização</div>
            </div>
            <div className={styles.favoritaToggle}>
              <button
                className={`${styles.toggleBtn} ${favoritaSim === true ? styles.toggleActive : ''}`}
                onClick={() => setFavoritaSim(true)}
              >Sim</button>
              <button
                className={`${styles.toggleBtn} ${favoritaSim === false ? styles.toggleNo : ''}`}
                onClick={() => setFavoritaSim(false)}
              >Não</button>
            </div>
          </div>

          {/* Venda e Pagamento */}
          <button className={styles.actionBtn} onClick={() => navigate(`/consultoras/${id}`)}>
            <span className={styles.actionIcon}>💰</span>
            <div className={styles.actionText}>
              <div className={styles.actionTitle}>Adicionar Venda e Pagamento</div>
              <div className={styles.actionSub}>Registro manual de valores</div>
            </div>
            <span className={styles.chevron}>›</span>
          </button>

          {/* Observação */}
          <button className={styles.actionBtn}>
            <span className={styles.actionIcon}>📝</span>
            <div className={styles.actionText}>
              <div className={styles.actionTitle}>Observação</div>
              <div className={styles.actionSub}>Texto ou voz — IA registra</div>
            </div>
            <span className={styles.chevron}>›</span>
          </button>

          {/* Finalizar */}
          <button className={styles.finalizarBtn} onClick={handleFinalizar}>
            <span>✅</span>
            <div>
              <div className={styles.finalizarTitle}>Finalizar Atendimento</div>
              <div className={styles.finalizarSub}>Marca como concluída · Abre a próxima</div>
            </div>
          </button>
        </div>
      </div>
    </div>
  )
}

function StatItem({ label, value, color }) {
  const colorMap = { green: 'var(--green)', red: 'var(--red)', default: 'var(--ink)' }
  return (
    <div style={{ padding: '12px 16px', borderRight: '1px solid var(--border)', borderBottom: '1px solid var(--border)' }}>
      <div style={{ fontSize: 10, fontWeight: 600, color: 'var(--ink-3)', textTransform: 'uppercase', letterSpacing: '.5px', marginBottom: 4 }}>{label}</div>
      <div style={{ fontSize: 17, fontWeight: 800, color: colorMap[color] ?? colorMap.default }}>{value}</div>
    </div>
  )
}

const fmt = (v) => `R$ ${Number(v).toLocaleString('pt-BR')}`
