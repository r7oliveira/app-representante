export default function ScreenCriarSemana() {
  return <div style={{ padding: 24, fontFamily: 'Inter', fontWeight: 700, color: '#6B6478' }}>🔧 ScreenCriarSemana — em breve</div>
}
