export default function ScreenRadar() {
  return <div style={{ padding: 24, fontFamily: 'Inter', fontWeight: 700, color: '#6B6478' }}>🔧 ScreenRadar — em breve</div>
}
