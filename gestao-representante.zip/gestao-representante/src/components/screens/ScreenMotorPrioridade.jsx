export default function ScreenMotorPrioridade() {
  return <div style={{ padding: 24, fontFamily: 'Inter', fontWeight: 700, color: '#6B6478' }}>🔧 ScreenMotorPrioridade — em breve</div>
}
