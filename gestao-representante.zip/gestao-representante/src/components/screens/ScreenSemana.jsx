// src/components/screens/ScreenSemana.jsx
import { useNavigate } from 'react-router-dom'
import useStore from '../../store/useStore'
import styles from './ScreenSemana.module.css'

// ── Dados de exemplo (substituir por Firebase) ──────────
const SEMANA_MOCK = {
  numero: 32,
  regiao: 'Gramado 3',
  totalConsultoras: 30,
  atendidas: 12,
  meta: 15000,
  vendido: 8400,
  recebido: 6200,
  cobrancasPendentes: 3800,
}

const CONSULTORAS_MOCK = [
  { id: '1', nome: 'Maria Souza',    iniciais: 'MS', status: 'concluida',  sub: 'Pedido R$ 920 · Recebeu R$ 400', score: 100 },
  { id: '2', nome: 'Ana Lima',       iniciais: 'AL', status: 'concluida',  sub: 'Sem pedido · Cobrança R$ 280',   score: 75  },
  { id: '3', nome: 'Juliana Rocha',  iniciais: 'JR', status: 'proxima',    sub: 'Score 60 · Último pedido há 21 dias', score: 60 },
  { id: '4', nome: 'Joana Ferreira', iniciais: 'JF', status: 'cobranca',   sub: 'Cobrança R$ 800 · 15 dias atraso', score: 45 },
  { id: '5', nome: 'Marta Leão',     iniciais: 'ML', status: 'pendente',   sub: 'Score 60 · Sugerido após 09:30',  score: 60 },
]

export default function ScreenSemana() {
  const navigate = useNavigate()
  const semana   = SEMANA_MOCK
  const pct      = Math.round((semana.atendidas / semana.totalConsultoras) * 100)
  const metaPct  = Math.round((semana.vendido / semana.meta) * 100)
  const proxima  = CONSULTORAS_MOCK.find(c => c.status === 'proxima')

  return (
    <div className={styles.screen}>

      {/* ── Hero ── */}
      <div className={styles.hero}>
        <div className={styles.heroWeek}>Semana {semana.numero}</div>
        <div className={styles.heroRegion}>{semana.regiao}</div>

        <div className={styles.progRow}>
          <span className={styles.progLabel}>Consultoras</span>
          <div className={styles.progTrack}>
            <div className={styles.progFill} style={{ width: `${pct}%` }} />
          </div>
          <span className={styles.progVal}>{semana.atendidas}/{semana.totalConsultoras}</span>
        </div>

        <div className={styles.progRow}>
          <span className={styles.progLabel}>Meta</span>
          <div className={styles.progTrack}>
            <div className={styles.progFill} style={{ width: `${metaPct}%` }} />
          </div>
          <span className={styles.progVal}>{metaPct}%</span>
        </div>

        <div className={styles.grid}>
          <StatBox label="Vendido"   value={fmt(semana.vendido)}             sub={`Meta: ${fmt(semana.meta)}`} />
          <StatBox label="Recebido"  value={fmt(semana.recebido)}            sub="Esta semana" />
          <StatBox label="Cobranças" value={fmt(semana.cobrancasPendentes)}  sub="⚠️ Pendentes" />
          <StatBox label="Pendentes" value={semana.totalConsultoras - semana.atendidas} sub="Consultoras" />
        </div>
      </div>

      {/* ── IA Strip ── */}
      <div className={styles.iaStrip}>
        <div className={styles.iaOrb}>✦</div>
        <p className={styles.iaTxt}>
          <strong>Faltam {fmt(semana.meta - semana.vendido)} para a meta.</strong>{' '}
          Hoje há R$ 1.200 em cobranças previstas. Próxima: {proxima?.nome}.
        </p>
      </div>

      {/* ── CTA ── */}
      <div className={styles.ctaWrap}>
        <button
          className={styles.ctaBtn}
          onClick={() => navigate(`/atendimento/${proxima?.id}`)}
        >
          Continuar Semana →
        </button>
        <p className={styles.ctaSub}>
          Próxima: {proxima?.nome} · {semana.atendidas + 1}ª de {semana.totalConsultoras}
        </p>
      </div>

      {/* ── Lista ── */}
      <div className={`${styles.list} scroll`}>
        <div className="section-title">Consultoras de hoje</div>
        {CONSULTORAS_MOCK.map(c => (
          <ConsultoraCard
            key={c.id}
            consultora={c}
            onClick={() => navigate(`/consultoras/${c.id}`)}
          />
        ))}
      </div>
    </div>
  )
}

/* ── Sub-componentes ── */
function StatBox({ label, value, sub }) {
  return (
    <div className={styles.statBox}>
      <div className={styles.statLabel}>{label}</div>
      <div className={styles.statVal}>{value}</div>
      <div className={styles.statSub}>{sub}</div>
    </div>
  )
}

function ConsultoraCard({ consultora: c, onClick }) {
  const map = {
    concluida: { cls: styles.done,     avCls: styles.avDone,    badge: 'Concluída', badgeCls: styles.badgeDone    },
    proxima:   { cls: styles.next,     avCls: styles.avDefault, badge: 'Próxima',   badgeCls: styles.badgeNext    },
    cobranca:  { cls: styles.alert,    avCls: styles.avAlert,   badge: 'Cobrança',  badgeCls: styles.badgeAlert   },
    pendente:  { cls: '',              avCls: styles.avDefault, badge: 'Pendente',  badgeCls: styles.badgePending },
  }
  const { cls, avCls, badge, badgeCls } = map[c.status] ?? map.pendente

  return (
    <div className={`${styles.card} ${cls}`} onClick={onClick}>
      <div className={`${styles.av} ${avCls}`}>
        {c.status === 'concluida' ? '✓' : c.status === 'cobranca' ? '⚠' : c.iniciais}
      </div>
      <div className={styles.info}>
        <div className={styles.nome}>{c.nome}</div>
        <div className={styles.sub}>{c.sub}</div>
      </div>
      <div className={`${styles.badge} ${badgeCls}`}>{badge}</div>
    </div>
  )
}

/* ── Helpers ── */
const fmt = (v) => `R$ ${Number(v).toLocaleString('pt-BR')}`
