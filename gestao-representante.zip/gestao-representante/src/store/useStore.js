// src/store/useStore.js
import { create } from 'zustand'

const useStore = create((set, get) => ({

  // ── AUTH ──────────────────────────────────────────────
  user: null,
  setUser: (user) => set({ user }),

  // ── SEMANA ATUAL ──────────────────────────────────────
  semanaAtual: null,
  setSemanaAtual: (semana) => set({ semanaAtual: semana }),

  // ── CONSULTORAS ───────────────────────────────────────
  consultoras: [],           // Cadastro Mestre completo
  setConsultoras: (list) => set({ consultoras: list }),

  consultoraDaSemana: [],    // Subset da semana atual
  setConsultoraDaSemana: (list) => set({ consultoraDaSemana: list }),

  // ── ATENDIMENTO ATIVO ─────────────────────────────────
  atendimentoAtivo: null,    // { consultora, horaInicio, ... }
  iniciarAtendimento: (consultora) => set({
    atendimentoAtivo: {
      consultora,
      horaInicio: new Date(),
    }
  }),
  encerrarAtendimento: () => set({ atendimentoAtivo: null }),

  // ── NAVEGAÇÃO ─────────────────────────────────────────
  telaAtiva: 'semana',       // 'semana' | 'consultoras' | 'mais'
  setTelaAtiva: (tela) => set({ telaAtiva: tela }),

  // ── HELPERS ───────────────────────────────────────────
  proximaConsultora: () => {
    const { consultoraDaSemana } = get()
    return consultoraDaSemana.find(c => c.status !== 'concluida') ?? null
  },
}))

export default useStore
