// src/App.jsx
import { Routes, Route, Navigate } from 'react-router-dom'
import Layout from './components/layout/Layout'
import ScreenSemana from './components/screens/ScreenSemana'
import ScreenConsultoras from './components/screens/ScreenConsultoras'
import ScreenConsultora from './components/screens/ScreenConsultora'
import ScreenAtendimento from './components/screens/ScreenAtendimento'
import ScreenMotorPrioridade from './components/screens/ScreenMotorPrioridade'
import ScreenRadar from './components/screens/ScreenRadar'
import ScreenCriarSemana from './components/screens/ScreenCriarSemana'
import ScreenAssistente from './components/screens/ScreenAssistente'
import ScreenMais from './components/screens/ScreenMais'

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        {/* Tela principal */}
        <Route index element={<Navigate to="/semana" replace />} />
        <Route path="semana" element={<ScreenSemana />} />

        {/* Consultoras */}
        <Route path="consultoras" element={<ScreenConsultoras />} />
        <Route path="consultoras/:id" element={<ScreenConsultora />} />

        {/* Fluxo de atendimento */}
        <Route path="atendimento/:id" element={<ScreenAtendimento />} />
        <Route path="prioridade/:id" element={<ScreenMotorPrioridade />} />

        {/* Radar e Assistente */}
        <Route path="radar" element={<ScreenRadar />} />
        <Route path="assistente" element={<ScreenAssistente />} />

        {/* Configuração */}
        <Route path="criar-semana" element={<ScreenCriarSemana />} />
        <Route path="mais" element={<ScreenMais />} />
      </Route>
    </Routes>
  )
}
