# Gestão · Representante Comercial
> Sistema operacional para representantes — React + Vite + Firebase

---

## Stack

| Camada | Tecnologia |
|---|---|
| Frontend | React 18 + Vite |
| Roteamento | React Router v6 |
| Estado global | Zustand |
| Banco de dados | Firebase Firestore |
| Autenticação | Firebase Auth |
| Storage (fotos) | Firebase Storage |
| Estilo | CSS Modules + variáveis globais |
| Deploy | GitHub Pages / Vercel |

---

## Como rodar localmente

```bash
# 1. Instalar dependências
npm install

# 2. Configurar Firebase
# Edite o arquivo: src/lib/firebase.js
# Substitua os valores com suas credenciais do Firebase Console

# 3. Rodar em desenvolvimento
npm run dev

# 4. Abrir no navegador
# http://localhost:3000
```

---

## Configurar Firebase

1. Acesse https://console.firebase.google.com
2. Crie um projeto chamado `gestao-representante`
3. Adicione um app Web
4. Copie as credenciais e cole em `src/lib/firebase.js`
5. Ative no console:
   - **Firestore Database** (modo de teste para começar)
   - **Authentication** → E-mail/senha
   - **Storage**

---

## Estrutura do projeto

```
src/
├── components/
│   ├── layout/
│   │   ├── Layout.jsx          ← Shell + navegação inferior
│   │   └── Layout.module.css
│   └── screens/
│       ├── ScreenSemana.jsx    ← Tela principal (semana atual)
│       ├── ScreenAtendimento.jsx ← Modo atendimento com cronômetro
│       ├── ScreenConsultoras.jsx
│       ├── ScreenConsultora.jsx
│       ├── ScreenMotorPrioridade.jsx
│       ├── ScreenRadar.jsx
│       ├── ScreenCriarSemana.jsx
│       ├── ScreenAssistente.jsx
│       └── ScreenMais.jsx
├── hooks/                      ← Custom hooks (Firebase, IA, etc)
├── lib/
│   └── firebase.js             ← Configuração Firebase
├── store/
│   └── useStore.js             ← Estado global (Zustand)
├── styles/
│   └── global.css              ← Variáveis e estilos base
├── App.jsx                     ← Rotas
└── main.jsx                    ← Entry point
```

---

## Rotas

| Rota | Tela |
|---|---|
| `/semana` | Tela principal — semana atual |
| `/consultoras` | Lista de consultoras da semana |
| `/consultoras/:id` | Ficha completa da consultora |
| `/atendimento/:id` | Modo atendimento (cronômetro + botões) |
| `/prioridade/:id` | Motor de prioridade — score |
| `/radar` | Radar da semana |
| `/assistente` | Assistente Comercial (IA proativa) |
| `/criar-semana` | Criar nova semana (3 passos) |
| `/mais` | Configurações, gerenciar região, importar |

---

## Próximas telas a desenvolver (em ordem)

- [ ] `ScreenConsultora` — ficha completa com CRM
- [ ] `ScreenCriarSemana` — fluxo 3 passos
- [ ] `ScreenMotorPrioridade` — score com critérios
- [ ] `ScreenRadar` — radar da semana
- [ ] `ScreenAssistente` — IA proativa
- [ ] `ScreenMais` — importação inteligente, gerenciar região

---

## Modelo de dados (Firestore)

```
/consultoras/{id}
  nome, cidade, regiao, telefone, cpf, endereco
  status: "ativa" | "inativa"
  pedidoFavorita: string[]
  score: number
  assinaturaDigital: boolean
  criadoEm: timestamp

/semanas/{id}
  numero: number
  regiao: string
  meta: number
  dataInicio: timestamp
  dataFim: timestamp
  status: "planejamento" | "em_andamento" | "concluida"

/semanas/{id}/atendimentos/{id}
  consultora_id: string
  horaInicio: timestamp
  horaFim: timestamp
  duracaoMin: number
  status: "pendente" | "em_andamento" | "concluido" | "remarcado"
  pedidoFavoritaFeito: boolean
  observacao: string
  audioUrl: string

/pedidos/{id}
  consultora_id: string
  atendimento_id: string
  valor: number
  fotoUrl: string
  criadoEm: timestamp

/cobrancas/{id}
  consultora_id: string
  valor: number
  vencimento: timestamp
  status: "pendente" | "pago" | "remarcado"
  formaPagamento: string
```

---

## Deploy no GitHub Pages

```bash
# 1. Instalar gh-pages
npm install --save-dev gh-pages

# 2. Adicionar ao package.json:
"homepage": "https://SEU_USUARIO.github.io/gestao-representante",
"scripts": {
  "predeploy": "npm run build",
  "deploy": "gh-pages -d dist"
}

# 3. Ajustar vite.config.js:
base: '/gestao-representante/'

# 4. Deploy
npm run deploy
```
